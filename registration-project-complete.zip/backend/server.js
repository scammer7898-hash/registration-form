require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const nodemailer = require('nodemailer');
const db = require('./db');
const util = require('util');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const query = util.promisify(db.query).bind(db);

// Config
const JWT_SECRET = process.env.JWT_SECRET || 'supersecret_jwt_key';
const ACCESS_EXPIRES = process.env.ACCESS_EXPIRES || '15m'; // access token lifetime
const REFRESH_EXPIRES_DAYS = parseInt(process.env.REFRESH_EXPIRES_DAYS || '7', 10);

// Nodemailer transporter - supports Ethereal for testing
async function createTransporter() {
    if (process.env.USE_ETHEREAL === 'true') {
        const testAccount = await nodemailer.createTestAccount();
        return nodemailer.createTransport({
            host: 'smtp.ethereal.email',
            port: 587,
            secure: false,
            auth: {
                user: testAccount.user,
                pass: testAccount.pass
            }
        });
    }
    return nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.example.com',
        port: process.env.SMTP_PORT || 587,
        secure: false,
        auth: {
            user: process.env.SMTP_USER || 'user@example.com',
            pass: process.env.SMTP_PASS || 'smtp_password'
        }
    });
}

async function sendMail(opts) {
    try {
        const transporter = await createTransporter();
        const info = await transporter.sendMail(opts);
        console.log('Mail sent:', info.messageId || info);
        if (process.env.USE_ETHEREAL === 'true') {
            console.log('Preview URL:', nodemailer.getTestMessageUrl(info));
            return { preview: nodemailer.getTestMessageUrl(info) };
        }
        return {};
    } catch (err) {
        console.error('sendMail error:', err.message);
        return {};
    }
}

// Helpers
function signAccessToken(payload) {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: ACCESS_EXPIRES });
}
function signRefreshToken(payload) {
    // long lived JWT stored server-side for revocation
    return jwt.sign(payload, JWT_SECRET, { expiresIn: (REFRESH_EXPIRES_DAYS*24)+'h' });
}

// Registration
app.post('/api/register', async (req, res) => {
    try {
        const { fullname, email, password } = req.body;
        if (!fullname || !email || !password) return res.status(400).json({ message: 'Missing fields' });

        const hash = await bcrypt.hash(password, 10);
        const verification_token = uuidv4();
        const sql = 'INSERT INTO users (fullname, email, password, verification_token) VALUES (?,?,?,?)';
        await query(sql, [fullname, email, hash, verification_token]);

        const verifyLink = `${process.env.FRONTEND_URL || 'http://localhost:5500'}/verify.html?token=${verification_token}&email=${encodeURIComponent(email)}`;
        const mail = {
            from: process.env.EMAIL_FROM || '"No Reply" <no-reply@example.com>',
            to: email,
            subject: 'Verify your account',
            text: 'Click to verify: ' + verifyLink,
            html: '<p>Click to verify: <a href="'+verifyLink+'">'+verifyLink+'</a></p>'
        };
        const mailInfo = await sendMail(mail);
        const resp = { message: 'User Registered. Check email to verify account.' };
        if (mailInfo.preview) resp.previewURL = mailInfo.preview;
        return res.status(201).json(resp);
    } catch (err) {
        console.error(err);
        return res.status(400).json({ message: 'Email already exists or invalid data' });
    }
});

// Verify email
app.post('/api/verify', async (req, res) => {
    try {
        const { email, token } = req.body;
        if (!email || !token) return res.status(400).json({ message: 'Missing email or token' });
        const rows = await query('SELECT id FROM users WHERE email = ? AND verification_token = ?', [email, token]);
        if (!rows.length) return res.status(400).json({ message: 'Invalid token or email' });
        await query('UPDATE users SET verified = 1, verification_token = NULL WHERE email = ?', [email]);
        return res.json({ message: 'Email verified successfully' });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});

// Login
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ message: 'Missing fields' });
        const rows = await query('SELECT * FROM users WHERE email = ?', [email]);
        if (!rows.length) return res.status(400).json({ message: 'Invalid credentials' });
        const user = rows[0];
        if (!user.verified) return res.status(401).json({ message: 'Email not verified' });
        const match = await bcrypt.compare(password, user.password);
        if (!match) return res.status(400).json({ message: 'Invalid credentials' });

        const payload = { id: user.id, email: user.email, is_admin: !!user.is_admin };
        const accessToken = signAccessToken(payload);
        const refreshToken = signRefreshToken({ id: user.id });

        // store refresh token
        const expiresAt = new Date(Date.now() + REFRESH_EXPIRES_DAYS*24*60*60*1000);
        await query('INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?,?,?)', [user.id, refreshToken, expiresAt]);

        return res.json({ message: 'Login successful', accessToken, refreshToken });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});

// Refresh token
app.post('/api/refresh', async (req, res) => {
    try {
        const { refreshToken } = req.body;
        if (!refreshToken) return res.status(400).json({ message: 'Missing refresh token' });
        // verify token signature
        let payload;
        try {
            payload = jwt.verify(refreshToken, JWT_SECRET);
        } catch (err) {
            return res.status(403).json({ message: 'Invalid refresh token' });
        }
        // check token exists in DB and not expired
        const rows = await query('SELECT * FROM refresh_tokens WHERE token = ? AND user_id = ?', [refreshToken, payload.id]);
        if (!rows.length) return res.status(403).json({ message: 'Refresh token revoked' });
        const rt = rows[0];
        if (new Date(rt.expires_at) < new Date()) {
            return res.status(403).json({ message: 'Refresh token expired' });
        }
        // issue new access token
        const userRows = await query('SELECT id, email, is_admin FROM users WHERE id = ?', [payload.id]);
        if (!userRows.length) return res.status(404).json({ message: 'User not found' });
        const user = userRows[0];
        const accessToken = signAccessToken({ id: user.id, email: user.email, is_admin: !!user.is_admin });
        return res.json({ accessToken });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});

// Request password reset
app.post('/api/request-reset', async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) return res.status(400).json({ message: 'Missing email' });
        const rows = await query('SELECT id FROM users WHERE email = ?', [email]);
        if (!rows.length) return res.status(200).json({ message: 'If the email exists, a reset link has been sent' }); // do not reveal
        const token = uuidv4();
        const expires = new Date(Date.now() + 60*60*1000); // 1 hour
        await query('UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?', [token, expires, email]);
        const resetLink = `${process.env.FRONTEND_URL || 'http://localhost:5500'}/reset_password.html?token=${token}&email=${encodeURIComponent(email)}`;
        const mail = {
            from: process.env.EMAIL_FROM || '"No Reply" <no-reply@example.com>',
            to: email,
            subject: 'Password reset request',
            text: 'Reset link: ' + resetLink,
            html: '<p>Reset link: <a href="'+resetLink+'">'+resetLink+'</a></p>'
        };
        const mailInfo = await sendMail(mail);
        const resp = { message: 'If the email exists, a reset link has been sent' };
        if (mailInfo.preview) resp.previewURL = mailInfo.preview;
        return res.json(resp);
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});

// Reset password
app.post('/api/reset-password', async (req, res) => {
    try {
        const { email, token, newPassword } = req.body;
        if (!email || !token || !newPassword) return res.status(400).json({ message: 'Missing fields' });
        const rows = await query('SELECT * FROM users WHERE email = ? AND reset_token = ?', [email, token]);
        if (!rows.length) return res.status(400).json({ message: 'Invalid token or email' });
        const user = rows[0];
        if (!user.reset_expires || new Date(user.reset_expires) < new Date()) return res.status(400).json({ message: 'Reset token expired' });
        const hash = await bcrypt.hash(newPassword, 10);
        await query('UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE email = ?', [hash, email]);
        return res.json({ message: 'Password reset successful' });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});

// Auth middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Missing token' });
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid token' });
        req.user = user;
        next();
    });
}

// Protected profile
app.get('/api/profile', authenticateToken, async (req, res) => {
    try {
        const rows = await query('SELECT id, fullname, email, verified, is_admin, created_at FROM users WHERE id = ?', [req.user.id]);
        if (!rows.length) return res.status(404).json({ message: 'User not found' });
        return res.json(rows[0]);
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});

// Admin users
app.get('/api/admin/users', authenticateToken, async (req, res) => {
    try {
        if (!req.user.is_admin) return res.status(403).json({ message: 'Admins only' });
        const rows = await query('SELECT id, fullname, email, verified, is_admin, created_at FROM users');
        return res.json(rows);
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
