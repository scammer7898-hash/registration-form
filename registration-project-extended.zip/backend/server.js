require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const nodemailer = require('nodemailer');
const db = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Configure these in a .env file in production
const JWT_SECRET = process.env.JWT_SECRET || 'supersecret_jwt_key';
const APP_URL = process.env.APP_URL || 'http://localhost:5000'; // used in verification link

// Nodemailer transporter placeholder - replace with real SMTP in production
const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.example.com',
    port: process.env.SMTP_PORT || 587,
    secure: false,
    auth: {
        user: process.env.SMTP_USER || 'user@example.com',
        pass: process.env.SMTP_PASS || 'smtp_password'
    }
});

// Helper: send verification email (in production configure SMTP properly)
function sendVerificationEmail(email, token) {
    const verifyLink = `${process.env.FRONTEND_URL || 'http://localhost:5500'}/verify.html?token=${token}&email=${encodeURIComponent(email)}`;
    const mailOptions = {
        from: process.env.EMAIL_FROM || '"No Reply" <no-reply@example.com>',
        to: email,
        subject: 'Verify your account',
        text: `Click the link to verify your account: ${verifyLink}`,
        html: `<p>Click the link to verify your account:</p><p><a href="${verifyLink}">${verifyLink}</a></p>`
    };
    // In many dev environments this will fail unless SMTP is configured.
    transporter.sendMail(mailOptions, (err, info) => {
        if (err) {
            console.error('Error sending verification email:', err.message);
        } else {
            console.log('Verification email sent:', info.response || info);
        }
    });
}

// Registration Route
app.post("/api/register", (req, res) => {
    const { fullname, email, password } = req.body;
    if (!fullname || !email || !password) return res.status(400).json({ message: 'Missing fields' });

    bcrypt.hash(password, 10, (err, hash) => {
        if (err) return res.status(500).json({ message: 'Server error' });

        const verification_token = uuidv4();
        const sql = "INSERT INTO users (fullname, email, password, verification_token) VALUES (?,?,?,?)";

        db.query(sql, [fullname, email, hash, verification_token], (err, result) => {
            if (err) {
                console.error(err);
                return res.status(400).json({ message: "Email already exists or invalid data" });
            }
            // attempt to send verification email (may require proper SMTP)
            sendVerificationEmail(email, verification_token);
            return res.status(201).json({ message: "User Registered. Check email to verify account." });
        });
    });
});

// Email verification endpoint (called from frontend verify page)
app.post("/api/verify", (req, res) => {
    const { email, token } = req.body;
    if (!email || !token) return res.status(400).json({ message: 'Missing email or token' });

    const sql = "SELECT * FROM users WHERE email = ? AND verification_token = ?";
    db.query(sql, [email, token], (err, results) => {
        if (err) return res.status(500).json({ message: 'Server error' });
        if (!results.length) return res.status(400).json({ message: 'Invalid token or email' });

        const update = "UPDATE users SET verified = 1, verification_token = NULL WHERE email = ?";
        db.query(update, [email], (err2) => {
            if (err2) return res.status(500).json({ message: 'Server error' });
            return res.json({ message: 'Email verified successfully' });
        });
    });
});

// Login Route
app.post("/api/login", (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Missing fields' });

    const sql = "SELECT * FROM users WHERE email = ?";
    db.query(sql, [email], (err, results) => {
        if (err) return res.status(500).json({ message: 'Server error' });
        if (!results.length) return res.status(400).json({ message: 'Invalid credentials' });

        const user = results[0];
        if (!user.verified) return res.status(401).json({ message: 'Email not verified' });

        bcrypt.compare(password, user.password, (err2, match) => {
            if (err2) return res.status(500).json({ message: 'Server error' });
            if (!match) return res.status(400).json({ message: 'Invalid credentials' });

            const payload = { id: user.id, email: user.email, is_admin: !!user.is_admin };
            const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '2h' });
            return res.json({ message: 'Login successful', token });
        });
    });
});

// Auth middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Missing token' });

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid token' });
        req.user = user;
        next();
    });
}

// Protected route: user profile
app.get("/api/profile", authenticateToken, (req, res) => {
    const sql = "SELECT id, fullname, email, verified, is_admin, created_at FROM users WHERE id = ?";
    db.query(sql, [req.user.id], (err, results) => {
        if (err) return res.status(500).json({ message: 'Server error' });
        if (!results.length) return res.status(404).json({ message: 'User not found' });
        return res.json(results[0]);
    });
});

// Admin-only route
app.get("/api/admin/users", authenticateToken, (req, res) => {
    if (!req.user.is_admin) return res.status(403).json({ message: 'Admins only' });
    db.query("SELECT id, fullname, email, verified, is_admin, created_at FROM users", (err, results) => {
        if (err) return res.status(500).json({ message: 'Server error' });
        return res.json(results);
    });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
