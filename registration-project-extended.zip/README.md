Extended Registration Project
=============================
Features added:
- JWT authentication (login returns token)
- Email verification workflow (token emailed; verify via verify.html)
- Protected user profile route
- Admin-only users list route
- Updated SQL schema

How to run:
1. Import database (run backend/db.sql in your MySQL)
2. Copy backend/.env.example to backend/.env and set real values
3. Install backend deps:
   cd backend
   npm install
4. Start backend:
   node server.js
5. Serve frontend files (you can use simple HTTP server, e.g. `npx serve frontend` or open via Live Server)
6. Register a user. To test admin routes set is_admin=1 manually in the DB for a user.

Notes:
- Email sending requires valid SMTP config. For testing you can log the verification token from server logs.
