const form = document.getElementById('registerForm');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fullname = document.getElementById('fullname').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const res = await fetch('http://localhost:5000/api/register', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({fullname, email, password})
  });
  const data = await res.json();
  const msg = data.message || JSON.stringify(data);
  document.getElementById('msg').textContent = msg + (data.previewURL ? (' (email preview: ' + data.previewURL + ')') : '');
});
