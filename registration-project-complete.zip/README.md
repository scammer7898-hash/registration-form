Complete Registration Project
=============================

What's new:
- Password reset: request a reset link (1 hour expiry) and update password.
- Refresh token support (stored in DB) and /api/refresh endpoint to obtain new access tokens.
- Ethereal test email support (set USE_ETHEREAL=true in backend/.env to get test SMTP and preview URLs).
- Full DB schema includes reset tokens and refresh_tokens table.

Quick setup:
1. Import DB schema:
   Run the SQL in backend/db.sql on your MySQL server.
2. Configure backend/.env (copy from .env.example) and set values.
   For testing emails without a real SMTP provider set USE_ETHEREAL=true
3. Install backend deps and start server:
   cd backend
   npm install
   node server.js
4. Serve frontend files:
   You can use a simple static server in frontend directory, e.g. `npx serve frontend` or open with Live Server.
5. Test flows:
   - Register a user, check console or ethereal preview URL for verification link.
   - Verify via verify.html
   - Login to receive accessToken & refreshToken
   - Use /api/refresh to exchange refreshToken for new accessToken
   - Request password reset via reset_request.html, check ethereal preview URL, then open reset_password.html to set a new password

Notes:
- For production: use secure SMTP, HTTPS, strong JWT secret, and consider rotating/revoking refresh tokens on logout.
- You can manually mark a user admin by setting is_admin=1 in the users table.
